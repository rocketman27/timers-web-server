package com.bnpparibas.tr.timer.migrations;

import org.springframework.boot.Banner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;

@SpringBootApplication
public class LiquibaseRunner {

    public static void main(String[] args) {
        SpringApplication app = new SpringApplication(LiquibaseRunner.class);
        app.setBannerMode(Banner.Mode.OFF);
        app.run(args);
    }

    // Exit after Liquibase applies migrations
    @EventListener(ApplicationReadyEvent.class)
    public void onReady() {
        // Let Liquibase run on startup via Spring Boot auto-config, then terminate
        System.exit(0);
    }
}


