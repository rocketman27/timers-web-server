# Timers DB Migrations

Standalone Liquibase runner for domain schema migrations (timers, executions, collections). Quartz tables are initialized by Spring in the app and are not managed here.

## Prerequisites
- Java 17+
- Gradle wrapper (used via `-p timers-db-migrations`)

## Changelog
- Location: `src/main/resources/db/changelog/db.changelog-master.yaml`
- Keep it in sync with the app’s baseline or move all domain changes here.

## Environment Variables
- `JDBC_URL` (required in non-H2): JDBC URL (e.g. `jdbc:postgresql://host:5432/timers`)
- `DB_USER` / `DB_PASS`: database credentials
- `CHANGELOG_FILE` (optional): path in classpath to changelog (default `db/changelog/db.changelog-master.yaml`)

## Build
```bash
./gradlew -p timers-db-migrations build
```

## Run (local)
Using default in-memory H2 (for quick smoke):
```bash
java -jar timers-db-migrations/build/libs/timers-db-migrations.jar
```
Against a real database:
```bash
JDBC_URL=jdbc:postgresql://localhost:5432/timers \
DB_USER=timers \
DB_PASS=secret \
java -jar timers-db-migrations/build/libs/timers-db-migrations.jar
```

## Authoring changes
Add new changes as changeSets in `db.changelog-master.yaml` (or include separate files). Example YAML:
```yaml
databaseChangeLog:
  - changeSet:
      id: 0001-create-timers
      author: you
      changes:
        - createTable:
            tableName: timers
            columns:
              - column:
                  name: id
                  type: varchar(64)
                  constraints:
                    primaryKey: true
                    nullable: false
              - column: { name: name, type: varchar(255), constraints: { nullable: false } }
              - column: { name: zone_id, type: varchar(128), constraints: { nullable: false } }
              - column: { name: trigger_time, type: time }
              - column: { name: suspended, type: boolean, defaultValueBoolean: false, constraints: { nullable: false } }
  - changeSet:
      id: 0002-create-timer-countries
      author: you
      changes:
        - createTable:
            tableName: timer_countries
            columns:
              - column: { name: timer_id, type: varchar(64), constraints: { nullable: false } }
              - column: { name: country, type: varchar(64), constraints: { nullable: false } }
        - addForeignKeyConstraint:
            baseTableName: timer_countries
            baseColumnNames: timer_id
            referencedTableName: timers
            referencedColumnNames: id
            constraintName: fk_timer_countries_timer
```
Tips:
- Prefer small, atomic changeSets with meaningful ids.
- For existing DBs, baseline with `changelogSync` once, then use `update`.
- Use `preConditions`, `rollback`, contexts, and labels where appropriate.

## CI/CD Integration
- Add a dedicated stage before app deploy:
  - Build once, then run the jar with `JDBC_URL/DB_USER/DB_PASS` envs.
- Alternative: use official Liquibase image and mount the changelog from this module.

## Notes
- This module manages only domain tables. Quartz schema remains under Spring control in the app (`spring.quartz.jdbc.initialize-schema`).
